<?php
    $pageTitle = __('Search Results ') .  __(' (%s total)', $total_results);
    echo head(array('title' => $pageTitle, 'bodyclass' => 'search'));
    $searchRecordTypes = get_search_record_types();
?>
    <h1><?php echo $pageTitle; ?></h1>
    <?php if ($total_results): ?>
        <div id="search-results">
            <div id="search-results-header" class="col-sm-12 hidden-xs">
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class=col-sm-6><h2><?php echo __('Title');?></h2></div>
                    <div class="col-sm-4"><h2><?php echo __('Creator');?></h2></div>
                </div>
            </div>
            <div>
                <?php $filter = new Zend_Filter_Word_CamelCaseToDash; ?>
                <?php foreach (loop('search_texts') as $searchText): ?>
                <?php $record = get_record_by_id($searchText['record_type'], $searchText['record_id']); ?>
                <?php $recordType = $searchText['record_type']; ?>

                <?php set_current_record($recordType, $record); ?>
                <div class="<?php echo strtolower($filter->filter($recordType));?>">
                    <div class="row">
                        <div class="col-sm-2">
                            <?php if ($recordImage = record_image($recordType, 'square_thumbnail')): ?>
                                <?php echo link_to($record, 'show', $recordImage, array('class' => 'image')); ?>
                            <?php endif; ?>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                            <a href="<?php echo record_url($record, 'show'); ?>"><?php echo $searchText['title'] ? $searchText['title'] : '[Unknown]'; ?></a>
                        </div>
                        <div class="col-sm-4 col-xs-12">
                            <?php echo metadata('item', array('Dublin Core', 'Creator')); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php echo pagination_links(); ?>
    <?php else: ?>
        <p><?php echo __('Your query returned no results.');?></p>
    <?php endif; ?>
<?php echo foot(); ?>