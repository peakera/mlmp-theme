      </div>
    </main>
    <footer role="contentinfo">
        <hr>
        <div class="container">
            <p class="text-center footer">
                <?php echo __('Copyrights for materials in the archive are retained by the original creators. All else copyright &copy; ') . date('Y') . ' ' . link_to_home_page(). 'All Rights Reserved.'; ?><br>
                <?php echo __('Proudly powered by <a href="http://omeka.org">Omeka</a>.'); ?>
            </p>
        </div>
        <?php fire_plugin_hook('public_footer', array('view' => $this)); ?>
        <script>
          (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
          (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
          m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
          })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

          ga('create', 'UA-99347371-1', 'auto');
          ga('send', 'pageview');
        </script>
    </footer>
</body>
</html>
