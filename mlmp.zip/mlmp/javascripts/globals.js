

(function($) {

	$(document).ready(function(){


	//Makes old Omeka buttons adhere to bootstrap styles
	$('#submit').addClass("btn btn-default");

	$(function() {
		//Sets initial state of accordion menu to uncollapsed
	    $( ".item-accordion" ).accordion({
	      collapsible: true,
	      active: false
	    });
	  });

	$(function () {

		//hTagcloud is generated on every simple page via the plugin (and is hidden by style.css)
		var tagCloud = $('.hTagcloud');
		//Appends the tag cloud to the appropriate div on the Explore page and displays it
		$('div.content-block__tag-cloud').append(tagCloud);
		$('.content-block__tag-cloud .hTagcloud').attr('style', 'display: unset;');

	});

	
	$(function() {

		//If there's a docviewer, replaces the media slot with the docviewer
		if (window.location.href.indexOf("items/show") > -1) {

		//Disables calendar.css on all item pages, so it won't interfere with the accordion menu
		$('link[href="http://militarylifememories.org/plugins/Calendar/views/public/css/calendar.css"]')[0].disabled=true;

		$(window).load(function(){

			if($('#docsviewer').length>0) {

			$('.content-block__media ul').hide();
			$('#docsviewer').prependTo('.content-block__media');
			}
		  
		});

		//Turns breaks in text input into paragraphs on item show pages
		if($('#item-text').length>0) {
			//Turns breaks in text input into paragraphs
			$('#item-text').html($('#item-text').html().replace(/<br>\\*/g,"</p><p id='item-text'>"));
			//Moves new paragraphs to be siblings of #item-text p
			$('#item-text').after(function(){
				return $('p', this);
			});
		}



		



		}


	});

	//Limits length of titles in shortcode carousels
	$(function(){
		$(".shortcode-carousel-title a").text(function(index, currentText) {
			
			var words = currentText.split(" ").filter(n => n);
			
			if (words.length > 7) {
				title = words.slice(1, 8).join(" ");
				return title + "..."
			}
		
		});
	});
	});
})(jQuery);

