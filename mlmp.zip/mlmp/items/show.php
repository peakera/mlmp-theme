<!-- Pulls the title of the page from the Dublin Core field Title and posts it in the head of the page -->
<?php 
    echo head(array('title' => metadata('item', array('Dublin Core', 'Title')), 'bodyclass' => 'items show'));
?>

    <div class="col-sm-12 content-block">
        <div class="col-sm-6 content-block__media content-block_item-border">
                <?php $images = $item->Files; $imagesCount = 1; ?>
                <?php if ($images): ?>
                <ul id="image-gallery" class="clearfix">
                    <?php foreach ($images as $image): ?>
                        <?php if ($imagesCount === 1): ?>
                            <img src="<?php echo url('/'); ?>files/original/<?php echo $image->filename; ?>" />
                            <div id="item-text">
                                <p><?php echo all_element_texts('item', array('show_empty_elements' => 'This data is not available.'));?></p>
                            </div>  
                        <?php endif; ?>
                    <?php $imagesCount++; endforeach; ?>
                </ul>
                <!-- If no image is present, prints the contents of the text field -->
                <?php else: ?>  
                    <div> 
                       <div id="item-text"><p>
                        <?php echo all_element_texts('item', array('show_empty_elements' => 'This data is not available.'));?></p>
                        </div>              
                    </div>
                <?php endif; ?>
        </div>
        <div class="col-sm-6 content-block__text metadata">
            <h1><?php echo metadata('item', array('Dublin Core', 'Title')); ?></h1>

            <p><?php echo metadata('item', array('Dublin Core', 'Description')); ?></p>

            <!-- The following prints the name of the creator for this item if a creator exists -->
            <?php $creator = metadata('item', array('Dublin Core', 'Creator')); ?>
            <?php if (!empty($creator)): ?>
                <div id="item-creator" class="element">
                    <h3><?php echo __('Created by '); ?><?php echo metadata('item', array('Dublin Core', 'Creator')); ?></h3>
                </div>
            <?php endif; ?>

             <!-- The following prints a citation for this item. -->
            <div id="item-citation" class="element">
                <h3><?php echo __('Citation'); ?></h3>
                <div class="element-text"><?php echo metadata('item', 'citation', array('no_escape' => true)); ?></div>
            </div>
        
            <!-- Begin collapsible accordion -->

            <div class="item-accordion">
            <h3><span class="fa fa-caret-down" aria-hidden="true"></span>   More Information</h3>

                <div class="accordion-body">
                <!-- The following returns all of the files associated with an item. -->
                <?php if (metadata('item', 'has files')): ?>
                    <div id="itemfiles" class="element">
                        <h4><?php echo __('Files'); ?></h4>
                        <div class="element-text"><?php echo files_for_item(); ?></div>
                    </div>
                <?php endif; ?>
                
                <!-- If the item belongs to a collection, the following creates a link to that collection. -->
                <?php if (metadata('item', 'Collection Name')): ?>
                    <div id="collection" class="element">
                        <h4><?php echo __('Collection'); ?></h4>
                        <div class="element-text"><p><?php echo link_to_collection_for_item(); ?></p></div>
                    </div>
                <?php endif; ?>
                
                <!-- The following prints a list of all tags associated with the item -->
                <?php if (metadata('item', 'has tags')): ?>
                    <div id="item-tags" class="element">
                        <h4><?php echo __('Tags'); ?></h4>
                        <div class="element-text"><?php echo tag_string('item'); ?></div>
                    </div>
                <?php endif;?>
                </div>
            
           
            </div>
            
        </div>
    </div>
    <div style="text-align: center;"> 
      <a href="http://militarylifememories.org/share" class="button__sys-button" style="margin-top: 50px;">Share Your Story Now</a>
    </div>
    
    
    <?php fire_plugin_hook('public_items_show', array('view' => $this, 'item' => $item)); ?>
    <ul class="pager">
        <li class="previous"><?php echo link_to_previous_item_show(); ?></li>
        <li class="next"><?php echo link_to_next_item_show(); ?></li>
    </ul>

<?php echo foot(); ?>
