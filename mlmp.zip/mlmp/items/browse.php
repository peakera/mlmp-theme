<?php
    $pageTitle = __('Browse Items');
    echo head(array('title'=>$pageTitle,'bodyclass' => 'items browse'));
?>

    <h1><?php echo 'Browse all items'; ?></h1>
    <?php $subnav = public_nav_items(); echo $subnav->setUlClass('nav nav-pills'); ?>
    <br/>
    <br/>
    <hr>    

    <?php echo item_search_filters(); ?>

    <div class="browse-items">
<!--         <?php if ($total_results > 0): ?>
        <?php
            $sortLinks[__('Title')] = 'Dublin Core,Title';
            $sortLinks[__('Creator')] = 'Dublin Core,Creator';
            $sortLinks[__('Date Added')] = 'added';
            ?>
            <div id="sort-links" >
            <span class="sort-label content-block_inline-block"><?php echo __('Sort by: '); ?></span><?php echo browse_sort_links($sortLinks); ?>
            </div> -->



            <div class="browse-items-header hidden-xs">
                <div class="row">
                    <div class="col-sm-2" style="display: none;">
                        <?php echo __('Sort by:'); ?>
                    </div>
                    <div class="col-sm-3 col-sm-offset-2 col-md-2 col-md-offset-2"><h2>
                        <?php echo browse_sort_links(array('Title'=>'Dublin Core,Title'), array('')); ?></h2>
                    </div>
                    <div class="col-sm-3 col-md-2"><h2>
                        <?php echo browse_sort_links(array('Creator'=>'Dublin Core,Creator'), array('')); ?></h2>
                    </div>
                    <div class="col-sm-4 col-md-4"><h2>
                    <?php echo browse_sort_links(array('Description'=>'Dublin Core,Description'), array('')); ?></h2>
                        
                    </div>
                </div>
            </div>
        
            <?php foreach (loop('items') as $item): ?>
            <div class="item">
                <div class="row">
                    <div class="col-sm-2 col-md-2">
                        <?php if(metadata('item', 'has thumbnail')): ?>
                            <div class="content-block_img-small">
                            <?php echo link_to_item(item_image('square_thumbnail')); ?>
                            </div>

                        <?php endif; ?>    
                        <?php /*$image = $item->Files; ?>
                        <?php if ($image) {
                                echo link_to_item('<div style="background-image: url(' . file_display_url($image[0], 'original') . ');" class="browse-img"></div>');
                            } else {
                                echo link_to_item('<div style="background-image: url(' . img('defaultImage@2x.jpg') . ');" class="browse-img"></div>');
                            } */
                        ?>
                    </div>
                    <div class="col-sm-3 col-md-2">
                        <?php echo link_to_item(metadata('item', array('Dublin Core', 'Title'))); ?>
                    </div>
                    <div class="col-sm-3 col-md-2">
                        <?php echo metadata('item', array('Dublin Core', 'Creator')); ?>
                    </div>
                  
                    <div class="col-sm-4 col-md-4">
                        <?php echo metadata('item', array('Dublin Core', 'Description'), array('snippet'=>150)); ?>
                        <?php if (metadata('item', 'has tags')): ?><div class="content-block"><p><strong><?php echo __('Tags'); ?>:</strong>
                        <?php echo tag_string('items'); ?></p>
                    </div><?php endif; ?>
                    </div>

                    
                
                    <?php fire_plugin_hook('public_items_browse_each', array('view' => $this, 'item' =>$item)); ?>
                </div>
            </div>
            <?php endforeach; ?>
            
            <div id="outputs" class="col-sm-12 col-md-12 content-block">
                <span class="outputs-label"><?php echo __('Export Results'); ?></span>
                <div id="output-btn">
                <?php echo output_format_list(true); ?>
                </div>
            </div> 
        <?php else : ?>
            <p><?php echo 'No items added, yet.'; ?></p>
        <?php endif; ?>
    </div>
    <?php echo pagination_links(); ?>

<?php fire_plugin_hook('public_items_browse', array('items'=>$items, 'view' => $this)); ?>
<?php echo foot(); ?>
