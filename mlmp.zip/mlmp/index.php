<?php echo head(array('bodyid'=>'home')); ?>

<div class="container-fluid">
	<div class="content-block">
	    <div class="col-sm-12 content-block ">
	        <div class="col-md-6 col-sm-12 content-block__media" id="home-img">
	                <?php if (get_theme_option('Display Featured Item') !== '0'): ?>
	                <?php echo $this->shortcodes('[featured_carousel showtitles=true speed=slow image_type=fullsize]'); ?>
	              

	                <?php endif; ?>    
	        </div>
	        <div class="col-sm-12" id="home-mobile-img">
	        	<img src="http://militarylifememories.org/files/original/f623725946879c7681ee04317b3f20ae.jpg" href="http://militarylifememories.org/items/show/15">
	        	<p>
	        		<a href="/items/show/15">Main Gate to Chaumont Air Base, France</a>
	        	</p>
	        </div>
	     
	        <div class="col-md-6 col-sm-12 content-block__text content-block_inline-block">
	            <p><?php echo get_theme_option('Homepage About'); ?></p>
	        </div>
	    </div>
	</div>
	<div class="content-block">
		<div class="col-sm-12 content-block">
			<div style="text-align: center; margin-top: 0px !important;"> 
          		<a href="http://militarylifememories.org/share" class="button__sys-button">Share Your Story Now</a>
        	</div>
		</div>
	</div>
	<div class="content-block">
	    <div class="col-sm-12 content-block ">
	        <h2><?php echo __('Recently Added Items'); ?></h2>
	        <?php echo $this->shortcodes('[recent_carousel showtitles=true]'); ?>
	        <p class="view-items-link"><a href="<?php echo html_escape(url('items')); ?>"><?php echo __('View All Items'); ?></a></p>
	    </div>
	    
	    <?php fire_plugin_hook('public_home', array('view' => $this)); ?>
	</div>
</div>

<?php echo foot(); ?>
